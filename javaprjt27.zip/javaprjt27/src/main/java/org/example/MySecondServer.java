package org.example;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class MySecondServer extends Thread{
    private int ClientNbre;
    public static void main(String[] args) {
        new MySecondServer().start();


    }

    @Override
    public void run(){
        try {
            ServerSocket ss = new ServerSocket(1234);
            System.out.println("The server is trying to start ...");
            while (true){
                Socket s = ss.accept();
                ++ClientNbre;
                new Communication(s,ClientNbre).start();
            }
        } catch (IOException e) {
           e.printStackTrace();
        }
    }
   public class Communication extends Thread{
        private Socket s;
        private int ClientNumber;
        Communication(Socket s, int ClientNumber){
            this.s=s;
            this.ClientNumber=ClientNumber;
        }
        @Override
       public void run(){
            try {
                InputStream is = s.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);

                OutputStream os = s.getOutputStream();
                String IP = s.getRemoteSocketAddress().toString();
                System.out.println("The client number" + ClientNumber + "and his IP" +IP );
                PrintWriter pw = new PrintWriter(os,true);
                pw.println("You are the client" +ClientNumber);
                while (true){
                    String UserRequest = br.readLine();
                     pw.println("La taille de votre chaine de caractere est : " + UserRequest.length());

                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
   }


}
