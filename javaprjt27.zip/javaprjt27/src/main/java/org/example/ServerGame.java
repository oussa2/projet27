package org.example;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.IllegalFormatException;
import java.util.Random;

public class ServerGame extends Thread{
    private int ClientNbre;
    private int SecretNbre;
    private boolean fin;
    private String Winner;

    public static void main(String[] args) {
        new ServerGame().start();


    }

    @Override
    public void run(){
        try {
            ServerSocket ss = new ServerSocket(1235);
            SecretNbre = new Random().nextInt (100);
            System.out.println(SecretNbre);
            System.out.println("The server is trying to start ...");
            while (true){
                Socket s = ss.accept();
                ++ClientNbre;
                new Communication(s,ClientNbre).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public class Communication extends Thread{
        private Socket s;
        private int ClientNumber;
        Communication(Socket s, int ClientNumber){
            this.s=s;
            this.ClientNumber=ClientNumber;
        }
        @Override
        public void run() {
            try {
                InputStream is = s.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);

                OutputStream os = s.getOutputStream();
                String IP = s.getRemoteSocketAddress().toString();
                System.out.println("The client number" + ClientNumber + " and his IP" + IP);
                PrintWriter pw = new PrintWriter(os, true);
                pw.println("You are the client" + ClientNumber);
                pw.println("Guess the secret number....");


                while (true) {
                    String UserRequest = br.readLine();
                    Boolean RequestFormat = false;
                    int UserNbre = 0;
                    try {
                        UserNbre = Integer.parseInt(UserRequest);
                        RequestFormat = true;
                    } catch (NumberFormatException e) {
                        pw.println("Give Number not sentence");
                    }
                    if (RequestFormat) {

                    }

                    System.out.println("The client" + ClientNbre + "sent the number " + UserNbre);
                    if (!fin) {
                        if (UserNbre > SecretNbre) pw.println("Your number is superior than the secret number");
                        else if (UserNbre < SecretNbre) pw.println("Your number is inferior than the secret number");
                        else {
                            pw.println("Excelent job, you have the good answer");
                            System.out.println("The winner is client number" + ClientNumber + " and his IP" + IP);
                            fin = true;

                        }
                    } else {
                        pw.println("Game over, wish you good luck next time..... and the winner is" + ClientNumber);
                    }


                }

            } catch (IOException e) {
                throw new RuntimeException(e);
            }



        }


        }
    }


